import { createHash, randomBytes } from "node:crypto";
import { createServer } from "node:http";
import { rm } from "node:fs/promises";
import { SITE_HOST } from "./config.mjs";
import { directMediaUrl, downloadDirect, downloadWithYtDlp } from "./download.mjs";
import { buttonText } from "./formats.mjs";
import {
  BUSY_TEXT,
  EMPTY_MEDIA_TEXT,
  EXPIRED_TEXT,
  NEED_LINK_TEXT,
  PICK_TEXT,
  PROBING_TEXT,
  START_TEXT,
  STRANGER_TEXT,
  TOO_BIG_TEXT,
  failureText,
  hostProblemText,
  unlockedOwnerText,
} from "./messages.mjs";
import { assertPublicHttpUrl } from "./net.mjs";
import { canonicalHost, commandName, extractUrl, matchPageUrl } from "./policy.mjs";
import { probe } from "./probe.mjs";
import { runProcess } from "./run.mjs";
import { Telegram } from "./telegram.mjs";

const token = (process.env.TELEGRAM_BOT_TOKEN || "").trim();
const ownerId = (process.env.TELEGRAM_OWNER_ID || "").trim();
const port = Number(process.env.PORT || 10000);
const tg = token ? new Telegram(token) : null;

/** @type {Map<string, any>} */
const jobs = new Map();
/** @type {Set<number>} */
const seen = new Set();
let busy = false;
let mode = "off";
let botUser = "";
let ytdlpVersion = "";
let ffmpegVersion = "";
let polling = false;
/** @type {Map<number, number>} */
const strangerTold = new Map();

/**
 * @param {number | undefined} userId
 */
function shouldTellStranger(userId) {
  if (!userId) return false;
  const now = Date.now();
  const prev = strangerTold.get(userId) || 0;
  if (now - prev < 10 * 60 * 1000) return false;
  strangerTold.set(userId, now);
  return true;
}

function publicBase() {
  const raw = (process.env.PUBLIC_URL || process.env.RENDER_EXTERNAL_URL || "").trim();
  if (raw.startsWith("https://")) return raw.replace(/\/$/, "");
  const host = (process.env.RENDER_EXTERNAL_HOSTNAME || "").trim();
  if (host) return `https://${host}`;
  return "";
}

function webhookSecret() {
  return createHash("sha256").update(token).digest("hex").slice(0, 32);
}

/**
 * @param {number} updateId
 */
function remember(updateId) {
  if (seen.has(updateId)) return false;
  seen.add(updateId);
  if (seen.size > 400) {
    const first = seen.values().next().value;
    if (first != null) seen.delete(first);
  }
  return true;
}

/**
 * @param {Record<string, unknown>} job
 */
function putJob(job) {
  const id = randomBytes(4).toString("hex");
  jobs.set(id, { ...job, exp: Date.now() + 20 * 60 * 1000 });
  while (jobs.size > 40) {
    const oldest = jobs.keys().next().value;
    if (!oldest) break;
    jobs.delete(oldest);
  }
  return id;
}

/**
 * @param {string} id
 */
function readJob(id) {
  const job = jobs.get(id);
  if (!job) return null;
  if (job.exp < Date.now()) {
    jobs.delete(id);
    return null;
  }
  return job;
}

/**
 * @param {number | undefined} userId
 */
function allowed(userId) {
  if (!userId) return { ok: false, kind: "stranger" };
  if (!ownerId) return { ok: false, kind: "unlocked" };
  if (String(userId) !== ownerId) return { ok: false, kind: "stranger" };
  return { ok: true, kind: "owner" };
}

/**
 * @param {number} chatId
 * @param {{ ok: boolean, kind: string }} gate
 * @param {number | undefined} userId
 */
async function reject(chatId, gate, userId) {
  if (!tg) return;
  if (gate.kind === "unlocked") await tg.sendMessage(chatId, unlockedOwnerText(userId ?? ""));
  else await tg.sendMessage(chatId, STRANGER_TEXT);
}

/**
 * @param {any} message
 */
async function onMessage(message) {
  if (!tg || !message?.chat || message.chat.type !== "private") return;
  const chatId = message.chat.id;
  const userId = message.from?.id;
  const text = String(message.text || "");
  const gate = allowed(userId);
  const command = commandName(text);

  if (!gate.ok) {
    if (shouldTellStranger(userId)) await reject(chatId, gate, userId);
    return;
  }

  if (command === "start" || command === "help") {
    await tg.sendMessage(chatId, START_TEXT);
    return;
  }
  if (command === "id") {
    await tg.sendMessage(chatId, `آیدی عددی تو: ${userId}`);
    return;
  }
  if (command === "site") {
    const host = canonicalHost(SITE_HOST);
    await tg.sendMessage(
      chatId,
      host
        ? `فقط لینک‌های ${host} و زیردامنه‌هایش.`
        : hostProblemText(SITE_HOST.trim() ? "bad-config" : "empty"),
    );
    return;
  }
  if (command) return;

  const url = extractUrl(text);
  if (!url) {
    await tg.sendMessage(chatId, NEED_LINK_TEXT);
    return;
  }
  const verdict = matchPageUrl(SITE_HOST, url);
  if (!verdict.ok) {
    await tg.sendMessage(chatId, hostProblemText(verdict.code, verdict.host));
    return;
  }

  const status = await tg.sendMessage(chatId, PROBING_TEXT);
  try {
    await assertPublicHttpUrl(verdict.url);
    const found = await probe(verdict.url);
    if (!found || !found.items.length) {
      await tg.editMessageText(chatId, status.message_id, EMPTY_MEDIA_TEXT);
      return;
    }
    const rows = found.items.map((item) => {
      const id = putJob({
        pageUrl: verdict.url,
        mode: found.mode,
        title: found.title,
        label: item.label,
        selector: item.selector,
        directUrl: item.directUrl,
        size: item.size,
      });
      return [{ text: buttonText(item), callback_data: `q:${id}` }];
    });
    await tg.editMessageText(chatId, status.message_id, found.title ? `${PICK_TEXT}\n${found.title}` : PICK_TEXT, {
      reply_markup: { inline_keyboard: rows },
    });
  } catch (error) {
    const code = /** @type {{ code?: string }} */ (error).code || "";
    await tg.editMessageText(chatId, status.message_id, failureText(code)).catch(() => {});
    console.error("probe failed", code || error);
  }
}

/**
 * @param {any} callback
 */
async function onCallback(callback) {
  if (!tg || !callback?.message?.chat || callback.message.chat.type !== "private") return;
  const chatId = callback.message.chat.id;
  const messageId = callback.message.message_id;
  const userId = callback.from?.id;
  const data = String(callback.data || "");
  const gate = allowed(userId);
  if (!gate.ok) {
    await tg.answerCallback(callback.id).catch(() => {});
    if (shouldTellStranger(userId)) await reject(chatId, gate, userId);
    return;
  }
  if (!data.startsWith("q:")) {
    await tg.answerCallback(callback.id).catch(() => {});
    return;
  }
  if (busy) {
    await tg.answerCallback(callback.id).catch(() => {});
    await tg.sendMessage(chatId, BUSY_TEXT);
    return;
  }
  busy = true;
  await tg.answerCallback(callback.id).catch(() => {});
  const job = readJob(data.slice(2));
  if (!job) {
    busy = false;
    await tg.sendMessage(chatId, EXPIRED_TEXT);
    return;
  }
  /** @type {{ dir?: string } | null} */
  let artifact = null;
  let lastEdit = 0;
  const report = (/** @type {number} */ pct) => {
    const now = Date.now();
    if (now - lastEdit < 4000) return;
    lastEdit = now;
    void tg.editMessageText(chatId, messageId, `در حال دانلود ${job.label}… ${pct}٪`).catch(() => {});
  };
  try {
    await tg.editMessageText(chatId, messageId, `در حال آماده‌کردن ${job.label}…`);
    await tg.sendChatAction(chatId, "upload_video").catch(() => {});
    artifact =
      job.mode === "direct"
        ? await downloadDirect(job.directUrl, job.pageUrl, report)
        : await downloadWithYtDlp(job.pageUrl, job.selector, report);
    if (artifact.tooBig) {
      let extra = "";
      if (job.mode === "ytdlp") {
        const media = await directMediaUrl(job.pageUrl, job.selector);
        if (media) extra = `\n\nلینک مستقیم همین کیفیت:\n${media}`;
      } else if (job.directUrl) {
        extra = `\n\nلینک مستقیم:\n${job.directUrl}`;
      }
      await tg.editMessageText(chatId, messageId, `${TOO_BIG_TEXT}${extra}`.slice(0, 4000));
      return;
    }
    const caption = [job.title, job.label].filter(Boolean).join("\n").slice(0, 900);
    const mp4 = artifact.filename.endsWith(".mp4") || artifact.filename.endsWith(".mov");
    try {
      if (!mp4) throw new Error("document");
      await tg.sendFile("sendVideo", chatId, artifact.filePath, "video.mp4", "video", {
        caption,
        supports_streaming: "true",
        reply_to_message_id: String(messageId),
      });
    } catch {
      await tg.sendFile("sendDocument", chatId, artifact.filePath, artifact.filename || "video.mp4", "document", {
        caption,
        reply_to_message_id: String(messageId),
      });
    }
    await tg
      .editMessageText(chatId, messageId, `فرستاده شد · ${job.label}`)
      .catch(() => {});
  } catch (error) {
    const code = /** @type {{ code?: string }} */ (error).code || "";
    if (code === "too-big") {
      await tg.editMessageText(chatId, messageId, TOO_BIG_TEXT).catch(() => {});
    } else {
      await tg.editMessageText(chatId, messageId, failureText(code)).catch(() => {});
      console.error("download failed", code || error);
    }
  } finally {
    busy = false;
    if (artifact?.dir) await rm(artifact.dir, { recursive: true, force: true }).catch(() => {});
  }
}

/**
 * @param {any} update
 */
async function handleUpdate(update) {
  if (!update || typeof update.update_id !== "number") return;
  if (!remember(update.update_id)) return;
  if (update.message) await onMessage(update.message);
  else if (update.callback_query) await onCallback(update.callback_query);
}

function statusHtml() {
  const host = canonicalHost(SITE_HOST);
  const rows = [
    ["توکن", token ? (botUser ? `وصل است (@${botUser})` : "گذاشته شده") : "خالی است"],
    ["مالک", ownerId ? "قفل شده" : "هنوز قفل نشده"],
    ["دامنه", host || (SITE_HOST.trim() ? "اشتباه پر شده" : "خالی — bot/config.mjs")],
    ["دریافت پیام", mode === "webhook" ? "webhook" : mode === "polling" ? "polling" : "خاموش"],
    ["yt-dlp", ytdlpVersion || "نصب نیست"],
    ["ffmpeg", ffmpegVersion || "نصب نیست"],
  ];
  const body = rows
    .map(
      ([label, value]) =>
        `<li><span>${escapeHtml(label)}</span><b>${escapeHtml(value)}</b></li>`,
    )
    .join("");
  return `<!doctype html>
<html lang="fa" dir="rtl">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>پیک</title>
<style>
  body { margin: 0; background: #14120f; color: #f4efe6; font-family: Tahoma, sans-serif; }
  main { max-width: 32rem; margin: 0 auto; padding: 2.5rem 1.25rem; }
  h1 { font-size: 1.8rem; margin: 0 0 .25rem; }
  p { color: #a89b8a; line-height: 1.6; }
  ul { list-style: none; padding: 0; margin: 1.5rem 0 0; }
  li { display: flex; justify-content: space-between; gap: 1rem; padding: .8rem 0; border-top: 1px solid #3a342b; }
  span { color: #a89b8a; }
</style>
<main>
  <h1>پیک</h1>
  <p>وضعیت سرویس. دانلود فقط از داخل تلگرام و فقط برای صاحب ربات انجام می‌شود.</p>
  <ul>${body}</ul>
</main>`;
}

/**
 * @param {string} value
 */
function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">");
}

/**
 * @param {import("node:http").IncomingMessage} req
 */
function readBody(req) {
  return new Promise((resolve, reject) => {
    /** @type {Buffer[]} */
    const chunks = [];
    let size = 0;
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > 1_000_000) {
        reject(new Error("big"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

const server = createServer(async (req, res) => {
  const path = (req.url || "/").split("?")[0];
  if (req.method === "GET" && (path === "/" || path === "/health")) {
    res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
    res.end(statusHtml());
    return;
  }
  if (req.method === "POST" && path === "/telegram/webhook") {
    if (!tg) {
      res.writeHead(404);
      res.end();
      return;
    }
    if (req.headers["x-telegram-bot-api-secret-token"] !== webhookSecret()) {
      res.writeHead(401);
      res.end();
      return;
    }
    let update;
    try {
      update = JSON.parse(await readBody(req));
    } catch {
      res.writeHead(200);
      res.end("ok");
      return;
    }
    res.writeHead(200, { "content-type": "text/plain" });
    res.end("ok");
    void handleUpdate(update).catch((error) => console.error("update failed", error));
    return;
  }
  res.writeHead(404);
  res.end();
});

async function bootTelegram() {
  if (!tg) {
    console.log("TELEGRAM_BOT_TOKEN is empty");
    return;
  }
  try {
    const me = await tg.call("getMe", {});
    botUser = me?.username || "";
  } catch (error) {
    console.error("getMe failed", error);
  }
  const base = publicBase();
  if (base) {
    try {
      await tg.call("setWebhook", {
        url: `${base}/telegram/webhook`,
        secret_token: webhookSecret(),
        allowed_updates: ["message", "callback_query"],
        drop_pending_updates: false,
      });
      mode = "webhook";
      console.log("webhook set");
      return;
    } catch (error) {
      console.error("setWebhook failed", error);
    }
  }
  try {
    await tg.call("deleteWebhook", { drop_pending_updates: false });
  } catch (error) {
    console.error("deleteWebhook failed", error);
  }
  mode = "polling";
  polling = true;
  void pollLoop();
}

async function pollLoop() {
  let offset = 0;
  while (polling && tg) {
    try {
      const updates = await tg.call(
        "getUpdates",
        { offset, timeout: 25, allowed_updates: ["message", "callback_query"] },
        35000,
      );
      for (const update of updates || []) {
        offset = update.update_id + 1;
        await handleUpdate(update);
      }
    } catch (error) {
      console.error("poll failed", error);
      await new Promise((resolve) => setTimeout(resolve, 2000));
    }
  }
}

async function toolVersions() {
  const ytdlp = await runProcess("yt-dlp", ["--version"], { timeoutMs: 8000, maxStdout: 2000 });
  if (!ytdlp.missing && ytdlp.code === 0) ytdlpVersion = ytdlp.stdout.trim().split("\n")[0] || "هست";
  const ffmpeg = await runProcess("ffmpeg", ["-version"], { timeoutMs: 8000, maxStdout: 2000 });
  if (!ffmpeg.missing && ffmpeg.code === 0) ffmpegVersion = "هست";
}

server.listen(port, "0.0.0.0", () => {
  console.log(`payk listening on ${port}`);
  void toolVersions();
  void bootTelegram();
});

function shutdown() {
  polling = false;
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 2000).unref();
}

process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
