// @ts-check

/**
 * @param {string} host
 */
function isIpLiteral(host) {
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) return true;
  if (host.includes(":")) return true;
  return false;
}

/**
 * @param {string} host
 */
export function isDnsHost(host) {
  if (!host || host.length > 253) return false;
  if (isIpLiteral(host)) return false;
  if (host === "localhost" || host.endsWith(".local") || host.endsWith(".localhost")) return false;
  if (!/^[\p{L}\p{N}.-]+$/u.test(host)) return false;
  if (host.startsWith(".") || host.endsWith(".") || host.includes("..")) return false;
  const labels = host.split(".");
  if (labels.length < 2) return false;
  if (labels.some((label) => !label || label.length > 63 || label.startsWith("-") || label.endsWith("-"))) {
    return false;
  }
  const tld = labels[labels.length - 1] ?? "";
  return /^[\p{L}]{2,}$/u.test(tld);
}

/**
 * @param {string} raw
 * @returns {string}
 */
export function canonicalHost(raw) {
  let value = String(raw ?? "").trim().toLowerCase();
  if (!value) return "";
  if (value.includes("://")) {
    try {
      value = new URL(value).hostname.toLowerCase();
    } catch {
      return "";
    }
  } else {
    value = value.split("/")[0] ?? "";
    value = value.split("?")[0] ?? "";
    value = value.split("#")[0] ?? "";
    value = value.replace(/:\d+$/, "");
  }
  value = value.replace(/\.$/, "").replace(/^www\./, "");
  if (!isDnsHost(value)) return "";
  return value;
}

/**
 * @param {string} input
 * @returns {{ state: "empty" | "ok" | "bad", host: string, line: string, note: string }}
 */
export function explainInput(input) {
  const original = String(input ?? "").trim();
  if (!original) {
    return {
      state: "empty",
      host: "",
      line: 'export const SITE_HOST = "";',
      note: "دامنه را بنویس تا خط آماده کپی شود. لینک یک ویدیو را اینجا نگذار.",
    };
  }
  const host = canonicalHost(original);
  if (!host) {
    return {
      state: "bad",
      host: "",
      line: 'export const SITE_HOST = "";',
      note: "این دامنه قابل قبول نیست. فقط نام سایت را بنویس، مثل example.com",
    };
  }
  return {
    state: "ok",
    host,
    line: `export const SITE_HOST = "${host}";`,
    note:
      original === host
        ? "همین خط را در bot/config.mjs جایگزین کن. لینک ویدیو را در فایل ننویس."
        : "متن را تمیز کردم. داخل فایل فقط همین خط را بگذار، نه آدرس کامل صفحه را.",
  };
}

/**
 * @param {string} configuredRaw
 * @param {string} urlString
 * @returns {{ ok: true, url: string, host: string } | { ok: false, code: "empty" | "bad-config" | "bad-url" | "wrong-host", host: string }}
 */
export function matchPageUrl(configuredRaw, urlString) {
  const configured = String(configuredRaw ?? "").trim();
  if (!configured) return { ok: false, code: "empty", host: "" };
  const allowed = canonicalHost(configured);
  if (!allowed) return { ok: false, code: "bad-config", host: "" };
  let url;
  try {
    url = new URL(urlString);
  } catch {
    return { ok: false, code: "bad-url", host: allowed };
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    return { ok: false, code: "bad-url", host: allowed };
  }
  if (url.username || url.password) return { ok: false, code: "bad-url", host: allowed };
  const host = url.hostname.toLowerCase().replace(/\.$/, "").replace(/^www\./, "");
  if (host !== allowed && !host.endsWith(`.${allowed}`)) {
    return { ok: false, code: "wrong-host", host: allowed };
  }
  return { ok: true, url: url.toString(), host: allowed };
}

/**
 * @param {string} text
 */
export function extractUrl(text) {
  const match = String(text ?? "").match(/https?:\/\/[^\s<>"']+/i);
  if (!match) return "";
  return match[0].replace(/[),.;]+$/g, "");
}

/**
 * @param {string} text
 */
export function commandName(text) {
  const match = String(text ?? "")
    .trim()
    .match(/^\/([a-z0-9_]+)(?:@\w+)?(?:\s|$)/i);
  return match ? (match[1] ?? "").toLowerCase() : "";
}
