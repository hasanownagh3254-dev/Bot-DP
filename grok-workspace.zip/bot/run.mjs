import { spawn } from "node:child_process";

/**
 * @param {string} cmd
 * @param {string[]} args
 * @param {{ timeoutMs?: number, maxStdout?: number, onStdout?: (chunk: string) => void }} [options]
 */
export function runProcess(cmd, args, options = {}) {
  const timeoutMs = options.timeoutMs ?? 40000;
  const maxStdout = options.maxStdout ?? 8_000_000;
  return new Promise((resolve) => {
    const child = spawn(cmd, args, { stdio: ["ignore", "pipe", "pipe"] });
    /** @type {Buffer[]} */
    const out = [];
    /** @type {Buffer[]} */
    const err = [];
    let outLen = 0;
    let errLen = 0;
    let missing = false;
    const timer = setTimeout(() => child.kill("SIGKILL"), timeoutMs);
    child.on("error", (error) => {
      if (error && /** @type {NodeJS.ErrnoException} */ (error).code === "ENOENT") missing = true;
    });
    child.stdout.on("data", (buf) => {
      const chunk = /** @type {Buffer} */ (buf);
      outLen += chunk.length;
      if (outLen > maxStdout) {
        child.kill("SIGKILL");
        return;
      }
      out.push(chunk);
      if (options.onStdout) options.onStdout(chunk.toString("utf8"));
    });
    child.stderr.on("data", (buf) => {
      const chunk = /** @type {Buffer} */ (buf);
      errLen += chunk.length;
      if (errLen < 120_000) err.push(chunk);
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      resolve({
        code: code ?? -1,
        stdout: Buffer.concat(out).toString("utf8"),
        stderr: Buffer.concat(err).toString("utf8"),
        missing,
      });
    });
  });
}
