/**
 * @param {string} url
 */
export function guessHeight(url) {
  const match = String(url).match(/(?:^|[^\d])(2160|1440|1080|720|480|360|240)(?:p)?(?:[^\d]|$)/i);
  return match ? Number(match[1]) : 0;
}

/**
 * @param {string} value
 */
function decodeBasic(value) {
  return value
    .replace(/&/g, "&")
    .replace(/"/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/</g, "<")
    .replace(/>/g, ">");
}

/**
 * @param {string} tag
 * @param {string} name
 */
function attr(tag, name) {
  const match = tag.match(new RegExp(`${name}\\s*=\\s*("([^"]*)"|'([^']*)')`, "i"));
  if (!match) return "";
  return decodeBasic(match[2] ?? match[3] ?? "");
}

/**
 * @param {string} value
 * @param {string} pageUrl
 * @param {Set<string>} into
 */
function pushUrl(value, pageUrl, into) {
  if (!value || value.startsWith("data:") || value.startsWith("blob:")) return;
  let abs;
  try {
    abs = new URL(value, pageUrl);
  } catch {
    return;
  }
  if (abs.protocol !== "http:" && abs.protocol !== "https:") return;
  const path = abs.pathname.toLowerCase();
  if (/\.(m3u8|mpd|ts|m4s|vtt|jpg|jpeg|png|gif|webp|svg)(?:$)/i.test(path)) return;
  if (!/\.(mp4|webm|mkv|mov|m4v)$/i.test(path) && !/[?&](format|mime)=video/i.test(abs.search)) {
    if (!/\.(mp4|webm|mkv|mov|m4v)(?:$|[?#])/i.test(abs.href)) return;
  }
  into.add(abs.toString());
}

/**
 * @param {string} html
 * @param {string} pageUrl
 * @returns {string[]}
 */
export function collectMedia(html, pageUrl) {
  const tagged = new Set();
  const bare = new Set();
  const source = String(html ?? "").slice(0, 1_500_000);

  for (const tag of source.match(/<(?:video|source)\b[^>]*>/gi) ?? []) {
    pushUrl(attr(tag, "src"), pageUrl, tagged);
  }
  for (const tag of source.match(/<meta\b[^>]*>/gi) ?? []) {
    const key = `${attr(tag, "property")} ${attr(tag, "name")}`.toLowerCase();
    if (!/og:video|twitter:player:stream/.test(key)) continue;
    pushUrl(attr(tag, "content"), pageUrl, tagged);
  }
  for (const match of source.matchAll(/"contentUrl"\s*:\s*"([^"]+)"/gi)) {
    pushUrl(decodeBasic(match[1] ?? ""), pageUrl, tagged);
  }
  if (tagged.size === 0) {
    for (const match of source.matchAll(
      /https?:\/\/[^\s"'<>\\]+?\.(?:mp4|webm|mkv|mov|m4v)(?:\?[^\s"'<>\\]*)?/gi,
    )) {
      pushUrl(match[0] ?? "", pageUrl, bare);
    }
  }
  const urls = [...(tagged.size ? tagged : bare)];
  urls.sort((a, b) => guessHeight(b) - guessHeight(a) || a.localeCompare(b));
  return urls.slice(0, 6);
}

/**
 * @param {string} url
 */
export function looksLikeMedia(url) {
  try {
    return /\.(mp4|webm|mkv|mov|m4v)$/i.test(new URL(url).pathname);
  } catch {
    return false;
  }
}
