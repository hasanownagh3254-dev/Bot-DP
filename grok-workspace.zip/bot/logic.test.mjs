import assert from "node:assert/strict";
import test from "node:test";
import { SITE_HOST } from "./config.mjs";
import { collectMedia } from "./extract.mjs";
import { buttonText, listQualities, selectorForHeight } from "./formats.mjs";
import { isPrivateIp } from "./net.mjs";
import { canonicalHost, explainInput, extractUrl, matchPageUrl } from "./policy.mjs";

test("site host is left empty for the owner to fill", () => {
  assert.equal(SITE_HOST, "");
});

test("canonical host strips scheme, www and path", () => {
  assert.equal(canonicalHost("https://WWW.Example.com/watch/12?q=1"), "example.com");
  assert.equal(canonicalHost("example.com"), "example.com");
  assert.equal(canonicalHost(""), "");
  assert.equal(canonicalHost("https://localhost/x"), "");
  assert.equal(canonicalHost("not a host"), "");
});

test("page url must stay on the configured site", () => {
  assert.equal(matchPageUrl("", "https://example.com/a").ok, false);
  assert.equal(matchPageUrl("https://www.example.com/video", "https://cdn.example.com/a.mp4").ok, true);
  const wrong = matchPageUrl("example.com", "https://notexample.com/a");
  assert.equal(wrong.ok, false);
  assert.equal(matchPageUrl("example.com", "https://example.com.evil.com/a").ok, false);
  assert.equal(matchPageUrl("example.com", "javascript:alert(1)").ok, false);
});

test("extracts the first http url", () => {
  assert.equal(extractUrl("ببین https://example.com/watch/12."), "https://example.com/watch/12");
});

test("explain input prepares the exact line", () => {
  const ready = explainInput("https://www.films.example/watch/9");
  assert.equal(ready.state, "ok");
  assert.equal(ready.line, 'export const SITE_HOST = "films.example";');
  assert.equal(explainInput("").state, "empty");
  assert.equal(explainInput("::::").state, "bad");
});

test("qualities keep the highest first and drop storyboards", () => {
  const listed = listQualities({
    title: "نمونه",
    formats: [
      { format_id: "18", ext: "mp4", height: 360, vcodec: "avc1", filesize: 5_000_000 },
      { format_id: "137", ext: "mp4", height: 1080, vcodec: "avc1", filesize: 40_000_000 },
      { format_id: "136", ext: "mp4", height: 720, vcodec: "avc1", filesize: 20_000_000 },
      { format_id: "248", ext: "webm", height: 1080, vcodec: "vp9", filesize: 30_000_000 },
      { format_id: "sb0", ext: "mhtml", height: 1080, vcodec: "none", format_note: "storyboard" },
    ],
  });
  assert.deepEqual(
    listed.items.map((item) => item.label),
    ["بهترین · 1080p", "720p", "360p"],
  );
  assert.equal(listed.items[0].selector.includes("height<="), false);
  assert.match(selectorForHeight(720), /height<=720/);
  assert.equal(buttonText(listed.items[1]).includes("720p"), true);
});

test("html media prefers tagged files and higher numbers", () => {
  const html = `
    <meta property="og:video" content="https://cdn.example.com/low.mp4">
    <video src="/media/480.mp4"></video>
    <source src="https://cdn.example.com/clip-1080p.mp4">
    <a href="https://ads.example.net/banner.mp4">ad</a>
  `;
  const urls = collectMedia(html, "https://example.com/watch/1");
  assert.equal(urls[0], "https://cdn.example.com/clip-1080p.mp4");
  assert.equal(urls.includes("https://ads.example.net/banner.mp4"), false);
  assert.equal(urls.some((url) => url.endsWith("/media/480.mp4")), true);
});

test("private addresses stay blocked", () => {
  assert.equal(isPrivateIp("127.0.0.1"), true);
  assert.equal(isPrivateIp("10.1.2.3"), true);
  assert.equal(isPrivateIp("192.168.1.8"), true);
  assert.equal(isPrivateIp("172.16.0.4"), true);
  assert.equal(isPrivateIp("169.254.169.254"), true);
  assert.equal(isPrivateIp("8.8.8.8"), false);
  assert.equal(isPrivateIp("::ffff:127.0.0.1"), true);
});
