import { openAsBlob } from "node:fs";

export class Telegram {
  /**
   * @param {string} token
   */
  constructor(token) {
    this.token = token;
    this.base = `https://api.telegram.org/bot${token}`;
  }

  /**
   * @param {string} method
   * @param {Record<string, unknown>} body
   * @param {number} [timeoutMs]
   */
  async call(method, body, timeoutMs = 20000) {
    const response = await fetch(`${this.base}/${method}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs),
    });
    const data = /** @type {{ ok?: boolean, description?: string, result?: any }} */ (
      await response.json().catch(() => ({}))
    );
    if (!data.ok) {
      const error = new Error(data.description || "telegram");
      /** @type {Error & { code?: string }} */ (error).code = "telegram";
      throw error;
    }
    return data.result;
  }

  /**
   * @param {number} chatId
   * @param {string} text
   * @param {Record<string, unknown>} [extra]
   */
  sendMessage(chatId, text, extra = {}) {
    return this.call("sendMessage", { chat_id: chatId, text: text.slice(0, 4000), ...extra });
  }

  /**
   * @param {number} chatId
   * @param {number} messageId
   * @param {string} text
   * @param {Record<string, unknown>} [extra]
   */
  editMessageText(chatId, messageId, text, extra = {}) {
    return this.call("editMessageText", {
      chat_id: chatId,
      message_id: messageId,
      text: text.slice(0, 4000),
      ...extra,
    });
  }

  /**
   * @param {string} id
   * @param {string} [text]
   */
  answerCallback(id, text = "") {
    return this.call("answerCallbackQuery", { callback_query_id: id, text: text.slice(0, 180) });
  }

  /**
   * @param {number} chatId
   * @param {string} action
   */
  sendChatAction(chatId, action) {
    return this.call("sendChatAction", { chat_id: chatId, action });
  }

  /**
   * @param {"sendVideo" | "sendDocument"} method
   * @param {number} chatId
   * @param {string} filePath
   * @param {string} filename
   * @param {string} field
   * @param {Record<string, string>} fields
   */
  async sendFile(method, chatId, filePath, filename, field, fields) {
    const blob = await openAsBlob(filePath);
    const form = new FormData();
    form.set("chat_id", String(chatId));
    form.set(field, blob, filename);
    for (const [key, value] of Object.entries(fields)) form.set(key, value);
    const response = await fetch(`${this.base}/${method}`, {
      method: "POST",
      body: form,
      signal: AbortSignal.timeout(120000),
    });
    const data = /** @type {{ ok?: boolean, description?: string }} */ (
      await response.json().catch(() => ({}))
    );
    if (!data.ok) {
      const error = new Error(data.description || "telegram");
      /** @type {Error & { code?: string }} */ (error).code = "telegram";
      throw error;
    }
    return data;
  }
}
