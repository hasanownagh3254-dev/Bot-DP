import { collectMedia, looksLikeMedia } from "./extract.mjs";
import { listQualities } from "./formats.mjs";
import { safeFetch } from "./net.mjs";
import { runProcess } from "./run.mjs";

/**
 * @param {string} pageUrl
 */
export async function probe(pageUrl) {
  if (looksLikeMedia(pageUrl)) {
    return {
      mode: "direct",
      title: "",
      items: [
        {
          id: "file",
          label: "فایل مستقیم",
          selector: "",
          directUrl: pageUrl,
          size: null,
          height: null,
        },
      ],
    };
  }

  const dumped = await runProcess(
    "yt-dlp",
    [
      "--ignore-config",
      "--no-playlist",
      "--no-warnings",
      "--no-cache-dir",
      "--socket-timeout",
      "20",
      "--retries",
      "1",
      "-J",
      pageUrl,
    ],
    { timeoutMs: 45000, maxStdout: 8_000_000 },
  );

  if (!dumped.missing && dumped.code === 0 && dumped.stdout.trim()) {
    try {
      const info = JSON.parse(dumped.stdout);
      const listed = listQualities(info);
      if (listed.items.length) {
        return {
          mode: "ytdlp",
          title: listed.title,
          items: listed.items.map((item) => ({ ...item, directUrl: "" })),
        };
      }
    } catch {
      /* fall through to html */
    }
  }

  const response = await safeFetch(pageUrl, {
    timeoutMs: 20000,
    headers: { accept: "text/html,application/xhtml+xml" },
  });
  if (!response.ok) {
    await response.body?.cancel();
    return null;
  }
  const type = response.headers.get("content-type") || "";
  if (type.startsWith("video/")) {
    await response.body?.cancel();
    return {
      mode: "direct",
      title: "",
      items: [
        {
          id: "file",
          label: "فایل مستقیم",
          selector: "",
          directUrl: pageUrl,
          size: Number(response.headers.get("content-length")) || null,
          height: null,
        },
      ],
    };
  }
  const html = await readTextCap(response, 1_500_000);
  const urls = collectMedia(html, pageUrl);
  if (!urls.length) return null;
  return {
    mode: "direct",
    title: titleFromHtml(html),
    items: urls.map((url, index) => ({
      id: `d${index}`,
      label: labelFor(url, index, urls.length),
      selector: "",
      directUrl: url,
      size: null,
      height: null,
    })),
  };
}

/**
 * @param {Response} response
 * @param {number} max
 */
async function readTextCap(response, max) {
  if (!response.body) return "";
  const reader = response.body.getReader();
  /** @type {Uint8Array[]} */
  const chunks = [];
  let size = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done || !value) break;
    size += value.byteLength;
    if (size > max) {
      chunks.push(value.subarray(0, value.byteLength - (size - max)));
      await reader.cancel();
      break;
    }
    chunks.push(value);
  }
  return new TextDecoder().decode(Buffer.concat(chunks.map((chunk) => Buffer.from(chunk))));
}

/**
 * @param {string} html
 */
function titleFromHtml(html) {
  const match = html.match(/<title[^>]*>([^<]{1,180})<\/title>/i);
  return match ? match[1].replace(/\s+/g, " ").trim() : "";
}

/**
 * @param {string} url
 * @param {number} index
 * @param {number} total
 */
function labelFor(url, index, total) {
  const height = url.match(/(?:^|[^\d])(2160|1440|1080|720|480|360|240)(?:p)?(?:[^\d]|$)/i);
  if (index === 0 && total > 1) {
    return height ? `بهترین · ${height[1]}p` : "بهترین فایل";
  }
  if (height) return `${height[1]}p`;
  return total === 1 ? "فایل ویدیو" : `فایل ${index + 1}`;
}
