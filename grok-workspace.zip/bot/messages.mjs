/**
 * @param {"empty" | "bad-config" | "bad-url" | "wrong-host"} code
 * @param {string} [host]
 */
export function hostProblemText(code, host) {
  if (code === "empty") {
    return [
      "دامنه سایت هنوز خالی است.",
      "فایل bot/config.mjs را باز کن و این خط را عوض کن:",
      "",
      'export const SITE_HOST = "example.com";',
      "",
      "example.com فقط الگوست. دامنه خودت را بگذار، بدون https:// و بدون / و بدون www.",
      "بعد ذخیره، سرویس Render را دوباره دیپلوی کن.",
      "لینک ویدیو را داخل فایل ننویس؛ آن را همین‌جا بفرست.",
    ].join("\n");
  }
  if (code === "bad-config") {
    return [
      "SITE_HOST اشتباه پر شده.",
      "فقط دامنه را بنویس. مثال:",
      "",
      'export const SITE_HOST = "example.com";',
    ].join("\n");
  }
  if (code === "wrong-host") {
    return `این لینک مال سایت تنظیم‌شده نیست.\nفقط لینک‌های ${host} قبول می‌شوند.`;
  }
  return "این متن لینک قابل قبول نیست. لینک کامل را بفرست؛ با https:// شروع شود.";
}

export const START_TEXT = [
  "پیک آماده‌ست.",
  "لینک ویدیو را بفرست. کیفیت‌ها را نشانت می‌دهم. دکمه اول بالاترین کیفیت است.",
  "",
  "دستورها:",
  "/id آیدی عددی تو",
  "/site دامنه‌ای که قبول می‌کنم",
].join("\n");

/**
 * @param {number | string} userId
 */
export function unlockedOwnerText(userId) {
  return [
    "هنوز صاحب ربات قفل نشده و دانلودی انجام نمی‌شود.",
    `آیدی عددی تو: ${userId}`,
    "",
    "در Render متغیر TELEGRAM_OWNER_ID را همین عدد بگذار و سرویس را ری‌استارت کن.",
  ].join("\n");
}

export const STRANGER_TEXT = "این ربات شخصی است و فقط برای صاحبش کار می‌کند.";

export const NEED_LINK_TEXT = "لینک کامل ویدیو را بفرست. باید با https:// شروع شود.";

export const PROBING_TEXT = "دارم کیفیت‌های همین لینک را درمی‌آورم…";

export const PICK_TEXT = "کدام کیفیت را بفرستم؟ دکمه اول بالاترین است.";

export const EMPTY_MEDIA_TEXT =
  "از این صفحه ویدیویی درنیامد. لینک را چک کن، یا مطمئن شو صفحه عمومی است و ورود نمی‌خواهد.";

export const BUSY_TEXT = "یک دانلود در جریان است. صبر کن تا تمام شود.";

export const EXPIRED_TEXT = "این دکمه منقضی شده. لینک را دوباره بفرست.";

export const TOO_BIG_TEXT =
  "این کیفیت از سقف ۵۰ مگابایت تلگرام بزرگ‌تر است. یک کیفیت پایین‌تر را بزن.";

export const SENT_FALLBACK_TEXT = "فرستاده شد.";

/**
 * @param {string} code
 */
export function failureText(code) {
  if (code === "dns") return "به این آدرس وصل نشدم. دامنه را چک کن.";
  if (code === "private") return "این آدرس قابل دانلود نیست.";
  if (code === "no-ytdlp") return "ابزار دانلود روی سرور نصب نیست. تصویر Docker را بدون تغییر بساز.";
  if (code === "empty" || code === "ytdlp") return EMPTY_MEDIA_TEXT;
  return "دانلود انجام نشد. لینک را دوباره بفرست.";
}
