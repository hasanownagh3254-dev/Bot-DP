import { createWriteStream } from "node:fs";
import { mkdtemp, readdir, rm, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { finished } from "node:stream/promises";
import { TELEGRAM_MAX_BYTES } from "./formats.mjs";
import { UA, safeFetch } from "./net.mjs";
import { runProcess } from "./run.mjs";

/**
 * @param {string} code
 */
function coded(code) {
  const error = new Error(code);
  /** @type {Error & { code?: string }} */ (error).code = code;
  return error;
}

/**
 * @param {import("node:stream").Readable} source
 * @param {string} filePath
 * @param {number} totalHint
 * @param {(pct: number) => void} [onProgress]
 */
async function writeCapped(source, filePath, totalHint, onProgress) {
  const sink = createWriteStream(filePath);
  let received = 0;
  try {
    for await (const chunk of source) {
      const buf = /** @type {Buffer} */ (chunk);
      received += buf.length;
      if (received > TELEGRAM_MAX_BYTES) throw coded("too-big");
      if (!sink.write(buf)) await new Promise((resolve) => sink.once("drain", resolve));
      if (totalHint > 0 && onProgress) onProgress(Math.min(99, Math.round((received / totalHint) * 100)));
    }
    sink.end();
    await finished(sink);
    return received;
  } catch (error) {
    sink.destroy();
    throw error;
  }
}

/**
 * @param {string} url
 * @param {string} pageUrl
 * @param {(pct: number) => void} [onProgress]
 */
export async function downloadDirect(url, pageUrl, onProgress) {
  const dir = await mkdtemp(join(tmpdir(), "payk-"));
  try {
    let pageOrigin = "";
    try {
      pageOrigin = new URL(pageUrl).origin;
    } catch {
      pageOrigin = "";
    }
    const response = await safeFetch(url, {
      timeoutMs: 4 * 60 * 1000,
      headers: pageOrigin ? { referer: `${pageOrigin}/`, "user-agent": UA } : { "user-agent": UA },
    });
    if (!response.ok || !response.body) {
      await response.body?.cancel();
      throw coded("empty");
    }
    const total = Number(response.headers.get("content-length") || 0);
    if (total > TELEGRAM_MAX_BYTES) {
      await response.body.cancel();
      return { tooBig: true, bytes: total, dir, filePath: "", filename: "" };
    }
    const filename = filenameFor(response.url || url, response.headers.get("content-type") || "");
    const filePath = join(dir, filename);
    const { Readable } = await import("node:stream");
    const bytes = await writeCapped(Readable.fromWeb(response.body), filePath, total, onProgress);
    return { tooBig: false, bytes, dir, filePath, filename };
  } catch (error) {
    await rm(dir, { recursive: true, force: true });
    throw error;
  }
}

/**
 * @param {string} url
 * @param {string} contentType
 */
function filenameFor(url, contentType) {
  const type = contentType.split(";")[0]?.trim() ?? "";
  const map = {
    "video/mp4": "mp4",
    "video/webm": "webm",
    "video/quicktime": "mov",
    "video/x-matroska": "mkv",
  };
  if (type in map) return `video.${map[/** @type {keyof typeof map} */ (type)]}`;
  try {
    const match = new URL(url).pathname.match(/\.(mp4|webm|mkv|mov|m4v)$/i);
    if (match) return `video.${match[1].toLowerCase()}`;
  } catch {
    /* ignore */
  }
  return "video.mp4";
}

/**
 * @param {string} pageUrl
 * @param {string} selector
 * @param {(pct: number) => void} [onProgress]
 */
export async function downloadWithYtDlp(pageUrl, selector, onProgress) {
  if (/[\r\n]/.test(selector)) throw coded("ytdlp");
  const dir = await mkdtemp(join(tmpdir(), "payk-"));
  let origin = pageUrl;
  try {
    origin = new URL(pageUrl).origin + "/";
  } catch {
    origin = pageUrl;
  }
  const result = await runProcess(
    "yt-dlp",
    [
      "--ignore-config",
      "--no-playlist",
      "--no-warnings",
      "--no-cache-dir",
      "--restrict-filenames",
      "--newline",
      "--retries",
      "2",
      "--fragment-retries",
      "2",
      "--socket-timeout",
      "20",
      "--merge-output-format",
      "mp4",
      "--user-agent",
      UA,
      "--add-header",
      `Referer: ${origin}`,
      "-f",
      selector,
      "-o",
      join(dir, "video.%(ext)s"),
      pageUrl,
    ],
    {
      timeoutMs: 4 * 60 * 1000,
      maxStdout: 2_000_000,
      onStdout(chunk) {
        const match = chunk.match(/(\d+(?:\.\d+)?)%/);
        if (match?.[1] && onProgress) onProgress(Math.min(99, Math.round(Number(match[1]))));
      },
    },
  );
  if (result.missing) {
    await rm(dir, { recursive: true, force: true });
    throw coded("no-ytdlp");
  }
  if (result.code !== 0) {
    await rm(dir, { recursive: true, force: true });
    const error = coded("ytdlp");
    console.error(result.stderr.slice(-500));
    throw error;
  }
  const names = await readdir(dir);
  if (!names.length) {
    await rm(dir, { recursive: true, force: true });
    throw coded("empty");
  }
  let filename = names[0] ?? "video.mp4";
  let bytes = -1;
  for (const name of names) {
    const info = await stat(join(dir, name));
    if (info.size > bytes) {
      filename = name;
      bytes = info.size;
    }
  }
  if (bytes > TELEGRAM_MAX_BYTES) {
    return { tooBig: true, bytes, dir, filePath: join(dir, filename), filename };
  }
  return { tooBig: false, bytes, dir, filePath: join(dir, filename), filename };
}

/**
 * @param {string} pageUrl
 * @param {string} selector
 */
export async function directMediaUrl(pageUrl, selector) {
  if (!selector || /[\r\n]/.test(selector)) return "";
  const result = await runProcess(
    "yt-dlp",
    ["--ignore-config", "--no-playlist", "--no-warnings", "-g", "-f", selector, pageUrl],
    { timeoutMs: 30000, maxStdout: 100_000 },
  );
  if (result.code !== 0) return "";
  const lines = result.stdout
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line.startsWith("https://"));
  if (lines.length !== 1) return "";
  if (/\.m3u8(?:$|\?)/i.test(lines[0] ?? "")) return "";
  return lines[0] ?? "";
}
