import { lookup } from "node:dns/promises";

export const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";

/**
 * @param {string} code
 */
function coded(code) {
  const error = new Error(code);
  /** @type {Error & { code?: string }} */ (error).code = code;
  return error;
}

/**
 * @param {string} ip
 */
export function isPrivateIp(ip) {
  const value = String(ip).toLowerCase().replace(/^\[|\]$/g, "");
  if (value.startsWith("::ffff:")) return isPrivateIp(value.slice(7));
  if (value === "::1" || value === "0.0.0.0") return true;
  if (value.startsWith("127.") || value.startsWith("10.") || value.startsWith("192.168.")) return true;
  if (value.startsWith("169.254.") || value.startsWith("fe80:") || value.startsWith("fc") || value.startsWith("fd")) {
    return true;
  }
  const match = value.match(/^172\.(\d+)\./);
  if (match) {
    const n = Number(match[1]);
    if (n >= 16 && n <= 31) return true;
  }
  return false;
}

/**
 * @param {string} host
 */
function isIpLiteral(host) {
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) return true;
  if (host.includes(":")) return true;
  return false;
}

/**
 * @param {string} raw
 */
export async function assertPublicHttpUrl(raw) {
  let url;
  try {
    url = new URL(raw);
  } catch {
    throw coded("bad-url");
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") throw coded("bad-url");
  if (url.username || url.password) throw coded("bad-url");
  const host = url.hostname.replace(/^\[|\]$/g, "").toLowerCase();
  if (!host || host === "localhost" || host.endsWith(".local") || host.endsWith(".internal")) {
    throw coded("private");
  }
  if (isIpLiteral(host)) {
    if (isPrivateIp(host)) throw coded("private");
    return url;
  }
  let records;
  try {
    records = await lookup(host, { all: true, verbatim: true });
  } catch {
    throw coded("dns");
  }
  if (!records.length) throw coded("dns");
  for (const record of records) {
    if (isPrivateIp(record.address)) throw coded("private");
  }
  return url;
}

/**
 * @param {string} raw
 * @param {RequestInit & { timeoutMs?: number }} [options]
 */
export async function safeFetch(raw, options = {}) {
  const { timeoutMs = 20000, ...rest } = options;
  let current = raw;
  for (let hop = 0; hop < 4; hop += 1) {
    const checked = await assertPublicHttpUrl(current);
    const response = await fetch(checked, {
      ...rest,
      redirect: "manual",
      signal: AbortSignal.timeout(timeoutMs),
      headers: {
        "user-agent": UA,
        accept: "*/*",
        ...(rest.headers ?? {}),
      },
    });
    if (response.status >= 300 && response.status < 400) {
      const location = response.headers.get("location");
      await response.body?.cancel();
      if (!location) throw coded("bad-url");
      current = new URL(location, checked).toString();
      continue;
    }
    return response;
  }
  throw coded("bad-url");
}
