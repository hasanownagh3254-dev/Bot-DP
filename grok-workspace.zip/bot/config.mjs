// فقط بین دو کوتیشن دامنه را بنویس.
// درست: example.com
// غلط:  https://example.com/watch/1   و   www.example.com
// لینک ویدیو را اینجا ننویس؛ آن را در تلگرام بفرست.
// توکن و آیدی عددی را اینجا ننویس. جای آن‌ها متغیر محیطی Render است.

export const SITE_HOST = "";
