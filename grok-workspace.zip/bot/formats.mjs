export const TELEGRAM_MAX_BYTES = 49 * 1024 * 1024;

export const BEST_SELECTOR = "bv*[ext=mp4]+ba[ext=m4a]/bv*+ba/b";

/**
 * @param {number} height
 */
export function selectorForHeight(height) {
  const h = Math.round(Number(height));
  if (!Number.isFinite(h) || h < 144 || h > 4320) return BEST_SELECTOR;
  return `bv*[height<=${h}][ext=mp4]+ba[ext=m4a]/bv*[height<=${h}]+ba/b[height<=${h}]/b`;
}

/**
 * @param {unknown} value
 */
function asNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : null;
}

/**
 * @param {string | undefined} title
 */
export function cleanTitle(title) {
  const text = String(title ?? "")
    .replace(/[\u0000-\u001f]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return text.slice(0, 140);
}

/**
 * @param {number | null | undefined} size
 */
export function formatBytes(size) {
  if (size == null || !Number.isFinite(size) || size <= 0) return "";
  const mb = size / (1024 * 1024);
  if (mb >= 10) return `${Math.round(mb)} مگابایت`;
  if (mb >= 1) return `${mb.toFixed(1)} مگابایت`;
  return `${Math.max(1, Math.round(size / 1024))} کیلوبایت`;
}

/**
 * Telegram inline buttons allow 64 bytes, not 64 characters.
 * @param {string} text
 */
function clipBytes(text, max = 64) {
  const bytes = Buffer.from(text);
  if (bytes.length <= max) return text;
  return bytes.subarray(0, max).toString("utf8").replace(/\uFFFD+$/u, "");
}

/**
 * @param {{ label: string, size: number | null }} item
 */
export function buttonText(item) {
  const size = formatBytes(item.size);
  const big = item.size != null && item.size > TELEGRAM_MAX_BYTES ? " · بزرگ" : "";
  return clipBytes(`${item.label}${size ? ` · ${size}` : ""}${big}`);
}

/**
 * @param {{ title?: string, formats?: unknown[] }} info
 */
export function listQualities(info) {
  const formats = Array.isArray(info?.formats) ? info.formats : [];
  /** @type {Map<number, number | null>} */
  const byHeight = new Map();
  for (const format of formats) {
    if (!format || typeof format !== "object") continue;
    const row = /** @type {Record<string, unknown>} */ (format);
    if (row.vcodec === "none" || row.vcodec == null) continue;
    const height = Number(row.height);
    if (!Number.isFinite(height) || height < 144) continue;
    const note = String(row.format_note ?? "");
    if (/storyboard/i.test(note)) continue;
    const ext = String(row.ext ?? "");
    if (ext === "mhtml" || ext === "jpg" || ext === "png" || ext === "webp") continue;
    const size = asNumber(row.filesize) ?? asNumber(row.filesize_approx);
    const prev = byHeight.get(height);
    if (prev == null || (size ?? 0) > (prev ?? 0)) byHeight.set(height, size);
  }
  const heights = [...byHeight.keys()].sort((a, b) => b - a).slice(0, 6);
  const bestHeight = heights[0] ?? null;
  /** @type {{ id: string, height: number | null, size: number | null, selector: string, label: string }[]} */
  const items = [
    {
      id: "best",
      height: bestHeight,
      size: bestHeight == null ? null : (byHeight.get(bestHeight) ?? null),
      selector: BEST_SELECTOR,
      label: bestHeight ? `بهترین · ${bestHeight}p` : "بهترین کیفیت",
    },
  ];
  for (const height of heights) {
    if (height === bestHeight) continue;
    items.push({
      id: String(height),
      height,
      size: byHeight.get(height) ?? null,
      selector: selectorForHeight(height),
      label: `${height}p`,
    });
  }
  return { title: cleanTitle(info?.title), items };
}
