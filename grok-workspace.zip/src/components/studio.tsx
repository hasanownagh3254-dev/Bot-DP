import { useEffect, useMemo, useState } from "react";
import { Check, Clapperboard, Copy, LockKeyhole } from "lucide-react";
import configSource from "../../bot/config.mjs?raw";
import { explainInput } from "../../bot/policy.mjs";

const QUALITIES = [
  { id: "best", label: "بهترین · 1080p · 38 مگابایت" },
  { id: "720", label: "720p · 16 مگابایت" },
  { id: "480", label: "480p · 8 مگابایت" },
];

const STEPS = [
  {
    n: "۰۱",
    title: "ربات را بساز",
    body: "در تلگرام به BotFather برو و newbot را بفرست. توکن را بردار و در هیچ فایلی ننویس.",
  },
  {
    n: "۰۲",
    title: "فقط دامنه را در کد بگذار",
    body: "در bot/config.mjs همان یک خط را با دامنه‌ات عوض کن. لینک ویدیو مال تلگرام است، نه این فایل.",
  },
  {
    n: "۰۳",
    title: "روی Render بالا بیاور",
    body: "Web Service با Docker همین پوشه. Worker نساز. خوابیدن سرویس رایگان اشکالی ندارد؛ پیام تو آن را بیدار می‌کند.",
  },
  {
    n: "۰۴",
    title: "دو متغیر را قفل کن",
    body: "TELEGRAM_BOT_TOKEN همان توکن است. TELEGRAM_OWNER_ID را خالی بگذار تا ربات آیدی عددی‌ات را بگوید، بعد همان عدد را بگذار و ری‌استارت کن.",
  },
];

function CodeLine({ line }: { line: string }) {
  const match = line.match(/^(export const SITE_HOST = )("(?:[^"\\]|\\.)*")(;.*)$/);
  if (!match) return <span>{line}</span>;
  return (
    <span>
      <span className="text-muted">{match[1]}</span>
      <span className="text-accent">{match[2]}</span>
      {match[3] ? <span>{match[3]}</span> : null}
      {match[2] === '""' ? <span className="caret" aria-hidden="true" /> : null}
    </span>
  );
}

export function Studio() {
  const [draft, setDraft] = useState("");
  const [copied, setCopied] = useState(false);
  const [picked, setPicked] = useState<string | null>(null);
  const [fieldReady, setFieldReady] = useState(false);
  const explained = useMemo(() => explainInput(draft), [draft]);
  const lines = configSource.replace(/\n$/, "").split("\n");

  useEffect(() => {
    setFieldReady(true);
  }, []);

  async function copyLine() {
    if (explained.state !== "ok") return;
    try {
      await navigator.clipboard.writeText(explained.line);
    } catch {
      const area = document.createElement("textarea");
      area.value = explained.line;
      document.body.appendChild(area);
      area.select();
      document.execCommand("copy");
      area.remove();
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  }

  return (
    <main className="mx-auto min-w-0 max-w-5xl px-4 py-8 sm:px-6 sm:py-12">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div className="min-w-0">
          <p className="flex items-center gap-2 text-sm text-muted">
            <Clapperboard className="size-4 text-accent" aria-hidden="true" />
            ربات شخصی تلگرام
          </p>
          <h1 className="mt-2 text-4xl font-semibold leading-tight">پیک</h1>
          <p className="mt-3 max-w-xl text-base text-muted">
            لینک صفحه را در تلگرام بفرست. کیفیت‌ها را نشانت می‌دهد و ویدیو را با همان کیفیت برمی‌گرداند. دکمه اول
            بالاترین است.
          </p>
        </div>
        <p className="inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface px-4 text-sm">
          <LockKeyhole className="size-4 text-accent" aria-hidden="true" />
          فقط آیدی خودت
        </p>
      </header>

      <div className="mt-8 grid min-w-0 gap-6 lg:grid-cols-5">
        <section className="min-w-0 overflow-hidden rounded-2xl border border-line bg-surface lg:col-span-3">
          <div className="flex items-center justify-between gap-3 border-b border-line px-4 py-3">
            <h2 className="font-mono text-sm text-fg" dir="ltr">
              bot/config.mjs
            </h2>
            <span className="text-sm text-muted">این خط هنوز خالی است</span>
          </div>
          <div className="overflow-x-auto px-4 py-4" dir="ltr">
            <ol className="m-0 list-none p-0 font-mono text-sm leading-7">
              {lines.map((line, index) => {
                const target = line.includes("SITE_HOST");
                return (
                  <li
                    key={`${index}-${line}`}
                    className={
                      target
                        ? "border-s-2 border-accent bg-surface-2 px-3 text-left"
                        : "px-3 text-left text-muted"
                    }
                  >
                    <span className="me-4 inline-block w-6 text-muted">{index + 1}</span>
                    <CodeLine line={line} />
                  </li>
                );
              })}
            </ol>
          </div>
          <div className="grid gap-3 border-t border-line px-4 py-4 sm:grid-cols-2">
            <p className="m-0 text-sm">
              <span className="text-muted">غلط </span>
              <span className="font-mono" dir="ltr">
                https://site.com/watch/1
              </span>
            </p>
            <p className="m-0 text-sm">
              <span className="text-muted">درست </span>
              <span className="font-mono text-accent" dir="ltr">
                site.com
              </span>
            </p>
          </div>
          <form
            className="border-t border-line px-4 py-4"
            onSubmit={(event) => {
              event.preventDefault();
              void copyLine();
            }}
          >
            <label htmlFor="host" className="text-sm font-medium">
              دامنه‌ات را امتحان کن
            </label>
            <div className="mt-2 flex flex-col gap-2 sm:flex-row">
              {fieldReady ? (
                <input
                  id="host"
                  name="host"
                  dir="ltr"
                  spellCheck={false}
                  placeholder="example.com"
                  value={draft}
                  onChange={(event) => {
                    setDraft(event.target.value);
                    setCopied(false);
                  }}
                  className="min-h-11 w-full min-w-0 rounded-xl border border-line bg-bg px-3 font-mono text-sm text-fg"
                />
              ) : (
                <div className="min-h-11 w-full min-w-0 rounded-xl border border-line bg-bg" />
              )}
              <button
                type="submit"
                disabled={explained.state !== "ok"}
                className="inline-flex min-h-11 shrink-0 items-center justify-center gap-2 rounded-xl bg-accent px-4 font-medium text-accent-fg disabled:opacity-40"
              >
                {copied ? <Check className="size-4" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
                {copied ? "کپی شد" : "کپی خط"}
              </button>
            </div>
            <p className="mt-3 font-mono text-sm text-fg" dir="ltr">
              {explained.line}
            </p>
            <p className="mt-2 text-sm text-muted" aria-live="polite">
              {explained.note}
            </p>
          </form>
        </section>

        <section className="min-w-0 rounded-2xl border border-line bg-surface p-4 lg:col-span-2">
          <h2 className="text-sm text-muted">نمونه گفتگو در تلگرام</h2>
          <div className="mt-3 rounded-2xl border border-line bg-bg p-3">
            <p className="mb-3 text-center text-sm text-muted">پیک</p>
            <div className="flex justify-start">
              <p className="max-w-[85%] rounded-2xl bg-accent px-3 py-2 text-sm text-accent-fg" dir="ltr">
                https://example.com/watch/12
              </p>
            </div>
            <div className="mt-3 flex justify-end">
              <div className="w-full max-w-[95%] rounded-2xl bg-surface-2 px-3 py-3 text-sm">
                {picked ? (
                  <p className="m-0">فرستاده شد · {picked}</p>
                ) : (
                  <>
                    <p className="m-0">کدام کیفیت را بفرستم؟ دکمه اول بالاترین است.</p>
                    <div className="mt-3 grid gap-2">
                      {QUALITIES.map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setPicked(item.label)}
                          className="min-h-11 rounded-xl border border-line bg-bg px-3 text-sm text-fg"
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>
            </div>
            {picked ? (
              <button
                type="button"
                onClick={() => setPicked(null)}
                className="mt-3 min-h-11 w-full rounded-xl text-sm text-muted"
              >
                دکمه‌ها را دوباره نشان بده
              </button>
            ) : null}
          </div>
          <p className="mt-3 text-sm text-muted">
            این فقط شکل کار است. دانلود واقعی بعد از بالا آمدن ربات، داخل تلگرام انجام می‌شود.
          </p>
        </section>
      </div>

      <section className="mt-6 rounded-2xl border border-line bg-surface">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-4 py-4">
          <h2 className="text-lg font-semibold">بردن روی Render</h2>
          <a
            href="/payk-bot.zip"
            download
            className="inline-flex min-h-11 items-center justify-center rounded-xl bg-accent px-4 font-medium text-accent-fg"
          >
            دانلود پوشه ربات
          </a>
        </div>
        <ol className="m-0 grid list-none gap-0 p-0 sm:grid-cols-2">
          {STEPS.map((step) => (
            <li key={step.n} className="border-t border-line px-4 py-4">
              <p className="m-0 font-mono text-sm text-accent">{step.n}</p>
              <h3 className="m-0 mt-1 text-base font-semibold">{step.title}</h3>
              <p className="m-0 mt-2 text-sm text-muted">{step.body}</p>
            </li>
          ))}
        </ol>
        <div className="overflow-x-auto border-t border-line">
          <table className="w-full text-sm">
            <thead className="text-muted">
              <tr>
                <th className="px-4 py-3 text-start font-medium">چیز</th>
                <th className="px-4 py-3 text-start font-medium">کجا</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-t border-line">
                <td className="px-4 py-3 font-mono" dir="ltr">
                  SITE_HOST
                </td>
                <td className="px-4 py-3">داخل bot/config.mjs</td>
              </tr>
              <tr className="border-t border-line">
                <td className="px-4 py-3 font-mono" dir="ltr">
                  TELEGRAM_BOT_TOKEN
                </td>
                <td className="px-4 py-3">متغیر محیطی Render</td>
              </tr>
              <tr className="border-t border-line">
                <td className="px-4 py-3 font-mono" dir="ltr">
                  TELEGRAM_OWNER_ID
                </td>
                <td className="px-4 py-3">متغیر محیطی Render</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <p className="mt-6 text-sm text-muted">
        فقط محتوایی را بگیر که حق ذخیره‌اش را داری. صفحه باید عمومی باشد؛ رمز و قفل DRM این‌جا باز نمی‌شود. اگر
        کسی جز تو لینک ربات را داشته باشد، جواب دانلود نمی‌گیرد.
      </p>
    </main>
  );
}
