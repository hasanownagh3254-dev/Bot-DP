import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Check, i as Clapperboard, n as LockKeyhole, r as Copy } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-wdsP5tg7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var config_default = "// فقط بین دو کوتیشن دامنه را بنویس.\n// درست: example.com\n// غلط:  https://example.com/watch/1   و   www.example.com\n// لینک ویدیو را اینجا ننویس؛ آن را در تلگرام بفرست.\n// توکن و آیدی عددی را اینجا ننویس. جای آن‌ها متغیر محیطی Render است.\n\nexport const SITE_HOST = \"\";\n";
/**
* @param {string} host
*/
function isIpLiteral(host) {
	if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) return true;
	if (host.includes(":")) return true;
	return false;
}
/**
* @param {string} host
*/
function isDnsHost(host) {
	if (!host || host.length > 253) return false;
	if (isIpLiteral(host)) return false;
	if (host === "localhost" || host.endsWith(".local") || host.endsWith(".localhost")) return false;
	if (!/^[\p{L}\p{N}.-]+$/u.test(host)) return false;
	if (host.startsWith(".") || host.endsWith(".") || host.includes("..")) return false;
	const labels = host.split(".");
	if (labels.length < 2) return false;
	if (labels.some((label) => !label || label.length > 63 || label.startsWith("-") || label.endsWith("-"))) return false;
	const tld = labels[labels.length - 1] ?? "";
	return /^[\p{L}]{2,}$/u.test(tld);
}
/**
* @param {string} raw
* @returns {string}
*/
function canonicalHost(raw) {
	let value = String(raw ?? "").trim().toLowerCase();
	if (!value) return "";
	if (value.includes("://")) try {
		value = new URL(value).hostname.toLowerCase();
	} catch {
		return "";
	}
	else {
		value = value.split("/")[0] ?? "";
		value = value.split("?")[0] ?? "";
		value = value.split("#")[0] ?? "";
		value = value.replace(/:\d+$/, "");
	}
	value = value.replace(/\.$/, "").replace(/^www\./, "");
	if (!isDnsHost(value)) return "";
	return value;
}
/**
* @param {string} input
* @returns {{ state: "empty" | "ok" | "bad", host: string, line: string, note: string }}
*/
function explainInput(input) {
	const original = String(input ?? "").trim();
	if (!original) return {
		state: "empty",
		host: "",
		line: "export const SITE_HOST = \"\";",
		note: "دامنه را بنویس تا خط آماده کپی شود. لینک یک ویدیو را اینجا نگذار."
	};
	const host = canonicalHost(original);
	if (!host) return {
		state: "bad",
		host: "",
		line: "export const SITE_HOST = \"\";",
		note: "این دامنه قابل قبول نیست. فقط نام سایت را بنویس، مثل example.com"
	};
	return {
		state: "ok",
		host,
		line: `export const SITE_HOST = "${host}";`,
		note: original === host ? "همین خط را در bot/config.mjs جایگزین کن. لینک ویدیو را در فایل ننویس." : "متن را تمیز کردم. داخل فایل فقط همین خط را بگذار، نه آدرس کامل صفحه را."
	};
}
var QUALITIES = [
	{
		id: "best",
		label: "بهترین · 1080p · 38 مگابایت"
	},
	{
		id: "720",
		label: "720p · 16 مگابایت"
	},
	{
		id: "480",
		label: "480p · 8 مگابایت"
	}
];
var STEPS = [
	{
		n: "۰۱",
		title: "ربات را بساز",
		body: "در تلگرام به BotFather برو و newbot را بفرست. توکن را بردار و در هیچ فایلی ننویس."
	},
	{
		n: "۰۲",
		title: "فقط دامنه را در کد بگذار",
		body: "در bot/config.mjs همان یک خط را با دامنه‌ات عوض کن. لینک ویدیو مال تلگرام است، نه این فایل."
	},
	{
		n: "۰۳",
		title: "روی Render بالا بیاور",
		body: "Web Service با Docker همین پوشه. Worker نساز. خوابیدن سرویس رایگان اشکالی ندارد؛ پیام تو آن را بیدار می‌کند."
	},
	{
		n: "۰۴",
		title: "دو متغیر را قفل کن",
		body: "TELEGRAM_BOT_TOKEN همان توکن است. TELEGRAM_OWNER_ID را خالی بگذار تا ربات آیدی عددی‌ات را بگوید، بعد همان عدد را بگذار و ری‌استارت کن."
	}
];
function CodeLine({ line }) {
	const match = line.match(/^(export const SITE_HOST = )("(?:[^"\\]|\\.)*")(;.*)$/);
	if (!match) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: line });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: match[1]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-accent",
			children: match[2]
		}),
		match[3] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: match[3] }) : null,
		match[2] === "\"\"" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "caret",
			"aria-hidden": "true"
		}) : null
	] });
}
function Studio() {
	const [draft, setDraft] = (0, import_react.useState)("");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [fieldReady, setFieldReady] = (0, import_react.useState)(false);
	const explained = (0, import_react.useMemo)(() => explainInput(draft), [draft]);
	const lines = config_default.replace(/\n$/, "").split("\n");
	(0, import_react.useEffect)(() => {
		setFieldReady(true);
	}, []);
	async function copyLine() {
		if (explained.state !== "ok") return;
		try {
			await navigator.clipboard.writeText(explained.line);
		} catch {
			const area = document.createElement("textarea");
			area.value = explained.line;
			document.body.appendChild(area);
			area.select();
			document.execCommand("copy");
			area.remove();
		}
		setCopied(true);
		window.setTimeout(() => setCopied(false), 2e3);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-w-0 max-w-5xl px-4 py-8 sm:px-6 sm:py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, {
								className: "size-4 text-accent",
								"aria-hidden": "true"
							}), "ربات شخصی تلگرام"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 text-4xl font-semibold leading-tight",
							children: "پیک"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-xl text-base text-muted",
							children: "لینک صفحه را در تلگرام بفرست. کیفیت‌ها را نشانت می‌دهد و ویدیو را با همان کیفیت برمی‌گرداند. دکمه اول بالاترین است."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface px-4 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, {
						className: "size-4 text-accent",
						"aria-hidden": "true"
					}), "فقط آیدی خودت"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid min-w-0 gap-6 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "min-w-0 overflow-hidden rounded-2xl border border-line bg-surface lg:col-span-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3 border-b border-line px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-mono text-sm text-fg",
								dir: "ltr",
								children: "bot/config.mjs"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: "این خط هنوز خالی است"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-x-auto px-4 py-4",
							dir: "ltr",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "m-0 list-none p-0 font-mono text-sm leading-7",
								children: lines.map((line, index) => {
									const target = line.includes("SITE_HOST");
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: target ? "border-s-2 border-accent bg-surface-2 px-3 text-left" : "px-3 text-left text-muted",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "me-4 inline-block w-6 text-muted",
											children: index + 1
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeLine, { line })]
									}, `${index}-${line}`);
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 border-t border-line px-4 py-4 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "m-0 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: "غلط "
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono",
									dir: "ltr",
									children: "https://site.com/watch/1"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "m-0 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: "درست "
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-accent",
									dir: "ltr",
									children: "site.com"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "border-t border-line px-4 py-4",
							onSubmit: (event) => {
								event.preventDefault();
								copyLine();
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "host",
									className: "text-sm font-medium",
									children: "دامنه‌ات را امتحان کن"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex flex-col gap-2 sm:flex-row",
									children: [fieldReady ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "host",
										name: "host",
										dir: "ltr",
										spellCheck: false,
										placeholder: "example.com",
										value: draft,
										onChange: (event) => {
											setDraft(event.target.value);
											setCopied(false);
										},
										className: "min-h-11 w-full min-w-0 rounded-xl border border-line bg-bg px-3 font-mono text-sm text-fg"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "min-h-11 w-full min-w-0 rounded-xl border border-line bg-bg" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "submit",
										disabled: explained.state !== "ok",
										className: "inline-flex min-h-11 shrink-0 items-center justify-center gap-2 rounded-xl bg-accent px-4 font-medium text-accent-fg disabled:opacity-40",
										children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "size-4",
											"aria-hidden": "true"
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
											className: "size-4",
											"aria-hidden": "true"
										}), copied ? "کپی شد" : "کپی خط"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-mono text-sm text-fg",
									dir: "ltr",
									children: explained.line
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted",
									"aria-live": "polite",
									children: explained.note
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "min-w-0 rounded-2xl border border-line bg-surface p-4 lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm text-muted",
							children: "نمونه گفتگو در تلگرام"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 rounded-2xl border border-line bg-bg p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-3 text-center text-sm text-muted",
									children: "پیک"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex justify-start",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "max-w-[85%] rounded-2xl bg-accent px-3 py-2 text-sm text-accent-fg",
										dir: "ltr",
										children: "https://example.com/watch/12"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 flex justify-end",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-full max-w-[95%] rounded-2xl bg-surface-2 px-3 py-3 text-sm",
										children: picked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "m-0",
											children: ["فرستاده شد · ", picked]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "m-0",
											children: "کدام کیفیت را بفرستم؟ دکمه اول بالاترین است."
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3 grid gap-2",
											children: QUALITIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setPicked(item.label),
												className: "min-h-11 rounded-xl border border-line bg-bg px-3 text-sm text-fg",
												children: item.label
											}, item.id))
										})] })
									})
								}),
								picked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setPicked(null),
									className: "mt-3 min-h-11 w-full rounded-xl text-sm text-muted",
									children: "دکمه‌ها را دوباره نشان بده"
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "این فقط شکل کار است. دانلود واقعی بعد از بالا آمدن ربات، داخل تلگرام انجام می‌شود."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 rounded-2xl border border-line bg-surface",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3 border-b border-line px-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: "بردن روی Render"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "/payk-bot.zip",
							download: true,
							className: "inline-flex min-h-11 items-center justify-center rounded-xl bg-accent px-4 font-medium text-accent-fg",
							children: "دانلود پوشه ربات"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "m-0 grid list-none gap-0 p-0 sm:grid-cols-2",
						children: STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "border-t border-line px-4 py-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "m-0 font-mono text-sm text-accent",
									children: step.n
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "m-0 mt-1 text-base font-semibold",
									children: step.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "m-0 mt-2 text-sm text-muted",
									children: step.body
								})
							]
						}, step.n))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto border-t border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-start font-medium",
									children: "چیز"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-start font-medium",
									children: "کجا"
								})] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-line",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-mono",
										dir: "ltr",
										children: "SITE_HOST"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: "داخل bot/config.mjs"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-line",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-mono",
										dir: "ltr",
										children: "TELEGRAM_BOT_TOKEN"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: "متغیر محیطی Render"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-line",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-mono",
										dir: "ltr",
										children: "TELEGRAM_OWNER_ID"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: "متغیر محیطی Render"
									})]
								})
							] })]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-muted",
				children: "فقط محتوایی را بگیر که حق ذخیره‌اش را داری. صفحه باید عمومی باشد؛ رمز و قفل DRM این‌جا باز نمی‌شود. اگر کسی جز تو لینک ربات را داشته باشد، جواب دانلود نمی‌گیرد."
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {});
}
//#endregion
export { Home as component };
