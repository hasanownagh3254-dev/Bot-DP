//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BAlHid2y.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CTw9u_a-.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CTw9u_a-.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CAt4ZeiQ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
